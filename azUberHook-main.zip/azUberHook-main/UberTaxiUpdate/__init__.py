import logging
import azure.functions as func


def main(req: func.HttpRequest, outputblob: func.Out[bytes]) -> func.HttpResponse:

    # data = req.get_json()
    # logging.warn(data)
   
    try:
        json = req.get_json()
        outputblob.set(req.get_body())
        return func.HttpResponse(
                "This HTTP triggered function executed successfully."
            )
    except Exception as e:
        print(e)
        return func.HttpResponse(
                "Err occured while validating the request." + "\r\n" + str(e) + "\r\n" + str(req.get_body())
            )


